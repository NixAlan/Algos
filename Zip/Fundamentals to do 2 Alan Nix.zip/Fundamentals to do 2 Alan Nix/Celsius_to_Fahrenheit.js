//Fahrenheit = (9/5 * Celsius) + 32

function fahrenheitToCelsius(cDegree) {
  var fDegree = 0;
  fDegree = cDegree * 1.8 + 32;
  console.log(fDegree);
}

fahrenheitToCelsius(100);
