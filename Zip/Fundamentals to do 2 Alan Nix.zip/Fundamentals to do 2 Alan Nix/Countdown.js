var numarr = [];
function newarr(num) {
  for (i = num; i >= 0; i--) numarr.push(i);
}
newarr(5);
console.log(numarr, numarr.length);
// numarr.length is one more then num
